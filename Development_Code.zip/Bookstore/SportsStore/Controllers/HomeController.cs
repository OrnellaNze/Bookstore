﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsStore.Models;
namespace SportsStore.Controllers
{
    public class HomeController: Controller
    {
        public ActionResult WhyUs()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
    }
}
