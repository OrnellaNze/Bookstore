﻿using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace SportsStore.Models {

    public static class SeedData {

        public static void EnsurePopulated(IApplicationBuilder app) {
            ApplicationDbContext context = app.ApplicationServices
                .GetRequiredService<ApplicationDbContext>();
            context.Database.Migrate();
            if (!context.Products.Any()) {
                context.Products.AddRange(
                    new Product {
                        Name = "The Hitchhiker's Guide to the Galaxy", 
                        Description = "Set in England in the early 19th century, Pride and Prejudice tells the story of Mr and Mrs Bennet's five unmarried daughters after the rich and eligible Mr Bingley and his status-conscious friend, Mr Darcy, have moved into their neighbourhood. While Bingley takes an immediate liking to the eldest Bennet daughter, Jane, Darcy has difficulty adapting to local society and repeatedly clashes with the second-eldest Bennet daughter, Elizabeth.",
                        Category = "Science Fiction", Price = 6.79m
                    },
                    new Product {
                        Name = "The Hobbit",
                        Description = "Large oblong or roundish fruit.",
                        Category = "Science Fiction", Price = 3.92m
                    },
                    new Product {
                        Name = "Farenheit 451",
                        Description = "Fahrenheit 451 (Ballantine Books, 1953) by Ray Bradbury is a dystopian novel that presents a future American society in which the masses are hedonistic and critical thought through reading is outlawed. Written in the early years of the Cold War, the novel is a critique of what Bradbury saw as issues in American society of the era.",
                        Category = "Science Fiction", Price = 5.73m
                    },
                    new Product {
                        Name = "The Appalachian Trail: A Biography",
                        Description = "The conception and building of the Appalachian Trail is a story of unforgettable characters who explored it, defined it, and captured national attention by hiking it",
                        Category = "Non-fiction", Price = 15.99m
                    },
                    new Product {
                        Name = "Life on the Line: Young Doctors Come of Age in a Pandemic",
                        Description = "The gripping account of six young doctors enlisted to fight COVID-19, an engrossing, eye-opening book in the tradition of both Sheri Fink’s Five Days at Memorial and Scott Turow’s One L.",
                        Category = "Non-fiction", Price = 18.59m
                    },
                    new Product {
                        Name = "The Old Man and The Sea",
                        Description = "Told in language of great simplicity and power, it is the story of an old Cuban fisherman, down on his luck, and his supreme ordeal -- a relentless, agonizing battle with a giant marlin far out in the Gulf Stream.",
                        Category = "Fiction", Price = 11.49m
                    },
                    new Product {
                        Name = "Invisible Man",
                        Description = "The book's nameless narrator describes growing up in a black community in the South, attending a Negro college from which he is expelled, moving to New York and becoming the chief spokesman of the Harlem branch of 'the Brotherhood', before retreating amid violence and confusion to the basement lair of the Invisible Man he imagines himself to be.",
                        Category = "Fiction", Price = 10.31m
                    },
                    new Product {
                        Name = "The Humanistic Tradition",
                        Description = "",
                        Category = "History", Price = 10.00m
                    },
                    new Product
                    {
                        Name = "Worlds Together, Worlds Apart",
                        Description = "",
                        Category = "History",
                        Price = 10.00m
                    },
                    new Product
                    {
                        Name = "Calculus",
                        Description = "",
                        Category = "Mathematics",
                        Price = 10.00m
                    },
                    new Product
                    {
                        Name = "Precalculus",
                        Description = "",
                        Category = "Mathematics",
                        Price = 10.00m
                    },
                    new Product
                    {
                        Name = "Algebra and Trigonometry",
                        Description = "",
                        Category = "History",
                        Price = 10.00m
                    }


                );
                context.SaveChanges();
            }
        }
    }
}
